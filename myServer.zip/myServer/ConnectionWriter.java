import java.io.*;
import java.net.*;

public class ConnectionWriter {
    public static void main(String[] args) throws Exception {

        String stringToReverse = URLEncoder.encode("my name is bob", "UTF-8");

        URL url = new URL("http://e23f1181.ngrok.io/text.txt");
        URLConnection connection = url.openConnection();
        connection.setDoOutput(true);

        OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
        out.write(stringToReverse);
        out.close();

        BufferedReader in = new BufferedReader(
                                    new InputStreamReader(
                                    connection.getInputStream()));
        String decodedString;
        while ((decodedString = in.readLine()) != null) {
            System.out.println(decodedString);
        }
        in.close();
    }

}