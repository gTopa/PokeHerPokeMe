import java.io.PrintWriter;

public class FileWrite {
 
    public static void main(String[] args) {
      try{
        PrintWriter out = new PrintWriter("filename.txt");
      out.println("hey there bby");
      out.close();
    }
    catch(java.io.FileNotFoundException e){
      e.printStackTrace();
    }
 
}
}