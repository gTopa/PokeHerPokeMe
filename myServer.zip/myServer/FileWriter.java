import java.io.FileWriter;
import java.io.IOException;

public class FileWrite {
 
    public static void main(String[] args) {
      PrintWriter out = new PrintWriter("filename.txt");
      out.println("hey there bby");
    }
 
}